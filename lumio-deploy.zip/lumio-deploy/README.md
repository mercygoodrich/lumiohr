# Lumio HR — Deployment Guide

## What's in this folder

```
lumio-deploy/
├── public/
│   └── index.html          ← Your landing page + playground
├── netlify/
│   └── functions/
│       └── ask-lumio.js    ← Serverless function (holds API key securely)
└── netlify.toml            ← Netlify config
```

---

## Deploy in 5 steps

### Step 1 — Get your Anthropic API key
1. Go to https://console.anthropic.com
2. Click "API Keys" in the left sidebar
3. Click "Create Key"
4. Copy the key (starts with `sk-ant-...`)
5. Save it somewhere safe — you only see it once

### Step 2 — Deploy to Netlify
1. Go to https://netlify.com and log in
2. Click "Add new site" → "Deploy manually"
3. Drag the entire `lumio-deploy` FOLDER onto the upload area
4. Wait for deploy (30 seconds)

### Step 3 — Add your API key (CRITICAL)
1. In Netlify, go to Site Settings → Environment Variables
2. Click "Add a variable"
3. Key: `ANTHROPIC_API_KEY`
4. Value: paste your key (sk-ant-...)
5. Click Save
6. Go to Deploys → "Trigger deploy" → "Deploy site"

### Step 4 — Test it
1. Open your site
2. Click "Try Lumio Free"
3. Ask: "What is the notice period in Germany?"
4. You should get a real, specific, conversational answer
5. If it works → the real Claude API is connected ✅
6. If it falls back to local answers → check the API key in step 3

### Step 5 — Set your domain
1. Netlify Settings → Domain Management
2. Add custom domain: lumio-hr.com
3. Follow DNS instructions

---

## How it works

```
User types question
       ↓
Browser sends to /.netlify/functions/ask-lumio
       ↓
Netlify function reads ANTHROPIC_API_KEY (secure, never in HTML)
       ↓
Calls Claude claude-sonnet-4-20250514 with HR system prompt
       ↓
Claude answers with real, specific, country-accurate HR advice
       ↓
Answer displayed in chat
```

If the API is unavailable → automatically falls back to local knowledge base.

---

## Costs

- Netlify: Free tier (125,000 function calls/month)
- Anthropic API: ~$0.003 per conversation (3 tenths of a cent)
- 1,000 conversations/month = ~$3

---

## Security

- API key is NEVER in the HTML file — only in Netlify environment variables
- Users cannot access your API key
- Each conversation is independent — no data stored
- All calls go through HTTPS

---

## Updating the site

1. Make changes to `public/index.html`
2. Drag the whole folder to Netlify again
   OR connect GitHub for auto-deploy

---

## Questions?

Email: mercygoodrich@gmail.com
Built with Claude AI by Lumio HR
